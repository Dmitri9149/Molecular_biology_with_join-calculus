class type c = object end;;
module type S = sig class c: c end;;
